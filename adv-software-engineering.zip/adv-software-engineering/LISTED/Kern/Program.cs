﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Security;
using System.Windows.Forms;
using LISTED.Plugin;
using LISTED.Adapter;

namespace LISTED.Kern
{
    static class Program
    {

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            
            ControlGui1 myControlGui1 = new ControlGui1();
        }
    }


}
