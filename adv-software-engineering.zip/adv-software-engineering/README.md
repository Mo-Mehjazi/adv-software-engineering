# adv-software-engineering

## What is LISTED?

It is a container of 1 or more lists to help you to keep all your notes and dates in 1 place! 
Simply add a new list and fill it up! Intuitive to use, nice and simple looks are what we want our products to be. 
If you are not convienced, please let us know via feedback formular that is sent directly to our developers.

Download it now!

## License

LISTED is free to use for everyone!
