using System;
using Microsoft.VisualStudio.TestPlatform.TestHost;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Test_LISTED;
using Test_LISTED.Presentation_Model;


namespace LISTED_UnitTest
{
    [TestClass]
    public class UT_IoDatastorge
    {
        [TestMethod]
        public void UT_int_IoDatastorage_WriteDataToStorage()
        {
            // arrange
            // act
            // assert
        }

        [TestMethod]
        public void UT_string_IoDataStorage_ReadDataFromStorage()
        {
            // arrange
            // act
            //assert
        }
    }
}
